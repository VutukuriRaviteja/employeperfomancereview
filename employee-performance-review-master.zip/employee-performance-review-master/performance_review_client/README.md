# performance_review_client

###Webpages explanation

####localhost:8080/ 

Welcome page that gives options to signin (either as admin or employee)

####localhost:8080/signin 

signin page

####localhost:8080/admin 

admin main page after sign in as admin. In here, you can to add/update/remove employee

####localhost:8080/admin/:employeeId 

admin entered to specific employee page. In here, you can view the employee profile,
add/update the employee's performance review, request feedback to other employees (including by itself) or reject feedback from other employees

####localhost:8080/employee/:employeeId 

employee main page after sign in as employee. In here, you can view the requiring feedbacks.
You can save/submit feedbacks after you completed. Once you submitted, you can't change it anymore. 

#### Unit tests will be done (still in progress)


