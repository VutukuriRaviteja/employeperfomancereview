/**
 * Created by Terry on 2016-11-29.
 */
import React from 'react';

export default () => {
    return <div>Welcome to Paytm</div>;
}