/**
 * Created by Terry on 2016-11-28.
 */
// Hold Applicatio secrets and config
export default {
    secret: "awdiajwikkviejikakclkijasdioawdjklknckxvlsd2312312dawds" //random string
};